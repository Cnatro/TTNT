def openFile():
    input_file = open("resource/data.txt")
    # for line in input_file:
    #     print(line, end='')

    print(input_file.read())
    input_file.close()

if __name__ == '__main__':
   openFile()