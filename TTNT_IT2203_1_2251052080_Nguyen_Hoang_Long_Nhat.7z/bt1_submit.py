# This is a sample Python script.
from typing import Tuple


# Press Shift+F10 to execute it or replace it with your code.
# Press Double Shift to search everywhere for classes, files, tool windows, actions, and settings.


def printMyName(name):
    for i in name:
        print(i, end=" ")


def oddCondition(start, end):
    arr = []
    for i in range(start, end + 1):
        if i % 2 != 0:
            arr.append(i)
    return arr


def cau3a(arr):
    return sum(arr)


def cau3b(start, end):
    tong = 0
    for i in range(start, end + 1):
        tong += i
    return tong


def cau4():
    mydict = {"a": 1, "b": 2, "c": 3, "d": 4}
    print(mydict.keys())
    print(mydict.values())
    print(mydict)


def cau5():
    courses = [131, 141, 142, 212]
    names = ["Maths", "Physics", "Chem", "Bio"]
    tuples = list(zip(courses, names))
    print(tuples)


def cau6a():
    word = "jabbawocky"
    vowels = "aeiouAEIOU"
    count = 0
    for char in word:
        if char.isalpha() and char not in vowels:
            count += 1
    # sum(1 for char in word if char not in vowels)

    print(count)


def cau6b():
    word = "jabbawocky"
    vowels = "aeiouAEIOU"
    count = 0
    for char in word:
        if char in vowels:
            continue
        if char.isalpha():
            count += 1

    print(count)


def cau7(start, end):
    for a in range(start, end):
        try:
            print(10 / a)
        except ZeroDivisionError:
            print("can’t divided by zero")


def cau8():
    ages = [23, 10, 80]
    names = ["Hoa", "Lam", "Nam"]
    tuples = list(zip(ages, names))
    print(sorted(tuples, key=lambda x: x[0]))


def print_hi():
    # data type : number
    print(sum((3, 2)))
    print(5 / 2)
    print(5 % 2)
    print(abs(-11))
    print(complex(1, 2))
    print((1 + 2j).real)
    print((1 + 2).imag)

    z = 1 + 2j
    w = 3 - 1j
    print(z + w)
    print(z * w)

    # data type: booleans
    print(True and False)
    print(True or False)
    print(not False)
    print(True + 41)
    print(False * 42)

    # data type : strings
    str = "abcdef"
    print(str[0])
    print(str[-1])
    print(str[1:4])
    print(str[1:5:2])
    print(str[::2])
    print(str[::-1])
    print(str.replace('b', 'nhat'))
    print(str.split())
    myList = [1, 'a', 6.6]
    print(myList)


# Press the green button in the gutter to run the script.
if __name__ == '__main__':
    # print_hi()
    printMyName("Nguyen Hoang Long Nhat")
    print()
    print(oddCondition(1, 11))
    print(cau3a(oddCondition(1, 10)))
    print(cau3b(1, 6))
    cau4()
    cau5()
    cau6a()
    cau6b()
    cau7(-2, 3)
    cau8()

# See PyCharm help at https://www.jetbrains.com/help/pycharm/
