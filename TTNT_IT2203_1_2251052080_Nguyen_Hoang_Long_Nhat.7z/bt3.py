import numpy as np
from unicodedata import normalize


def cau1(a, b):
    return sum([a, b])


def cau2():
    matrix = np.array([[1, 2, 3], [4, 5, 6], [7, 8, 9]])
    vector = np.array([1, 2, 3])

    rank_matrix = np.linalg.matrix_rank(matrix)
    matrix_vector = np.dot(matrix, vector)

    print(f"Bậc của ma trận {rank_matrix}")
    print(f"Hình của ma trận {matrix.shape}")
    print(f"Hinh của vector {vector.shape}")
    print(f"Hình của ma trận và vector {matrix_vector.shape}")


def cau3():
    matrix = np.array([[1, 2, 3], [4, 5, 6], [7, 8, 9]])
    new_matrix = matrix + 3
    print(matrix)
    print(new_matrix)


def cau4():
    matrix = np.array([[1, 2, 3], [4, 5, 6], [7, 8, 9]])
    vector = np.array([1, 2, 3])

    transpose_matrix = matrix.T
    transpose_vector = vector.T

    print(f"Ma tran cu \n{matrix}")
    print(f"Ma tran moi \n{transpose_matrix}")
    print(f"Vector cu \n{vector}")
    print(f"Ma tran moi \n{transpose_vector}")


def cau5():
    x = np.array([2, 7])
    norm_x = np.linalg.norm(x)
    normalized_x = x / norm_x

    print(f"Norm {norm_x}")
    print(f"normalized {normalized_x}")


def cau6():
    a = np.array([10, 15])
    b = np.array([8, 2])
    c = np.array([1, 2, 3])

    a_plus_b = a + b
    a_minus_b = a - b
    try:
        a_minus_c = a - c
    except ValueError as e:
        a_minus_c = str(e)

    print(f"a + b =  {a_plus_b}")
    print(f"a - b =  {a_minus_b}")
    print(f"a - c =  {a_minus_c}")


def cau7():
    a = np.array([10, 15])
    b = np.array([8, 2])
    a_dot_b = np.dot(a, b)
    print(f"a dot b = {a_dot_b}")


def cau8():
    a = np.array([[2, 4, 9], [3, 6, 7]])
    print(a)
    print(f"Bac cua ma tran a {np.linalg.matrix_rank(a)}")
    print(f"Hinh cua ma tran a {a.shape}")
    print(f"gia tri 7 cua a {a[1, 2]}")
    print(a[:, 1])


def cau9():
    matrix_random = np.random.randint(-10, 11, size=(3, 3))
    print(f"Ma tran ngau nhien \n{matrix_random}")


def cau10():
    matrix_donVi = np.zeros((3, 3))
    for i in range(3):
        matrix_donVi[i, i] = 1

    print(f"Ma tran don vi \n{matrix_donVi}")


def cau11():
    matrix_random = np.random.randint(1, 11, size=(3, 3))
    trace1 = np.trace(matrix_random)
    trace2 = 0

    for i in range(3):
        trace2 += matrix_random[i, i]

    print(f' a = {trace1}')
    print(f' b = {trace2}')


def cau12():
    diagonal_matrix = np.diag([1, 2, 3])
    print(f"ma tran duong cheo {diagonal_matrix}")


def cau13():
    matrix = np.array([[1, 1, 2], [2, 4, -3], [3, 6, -5]])

    # Tính định mức (determinant) của A
    det_matrix = np.linalg.det(matrix)

    print("Định thuc của ma trận A:", det_matrix)


def cau14():
    a1 = np.array([1, -2, -5])
    a2 = np.array([2, 5, 6])
    matrix = np.column_stack((a1, a2))

    print("ma trận :", matrix)


def cau16():
    even_values = np.linspace(0, 32, 4)
    print("4 giá trị cách đều giữa 0 và 32:", even_values)


if __name__ == '__main__':
    # print(cau1(3,2))
    cau2()
    cau3()
    cau4()
    cau5()
    cau6()
    cau7()
    cau8()
    cau9()
    cau10()
    cau11()
    cau12()
    cau13()
    cau14()
    cau16()